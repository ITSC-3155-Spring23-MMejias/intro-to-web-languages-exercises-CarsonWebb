number1=int(input('Enter an integer greater than 1:'))
number2=number1*number1*number1
print(f'The cube of {number1} is {number2}')