grade=int(input('Enter a grade from 0-100:'))
if (90<=grade)&(grade<=100):
    print('You grade is an A')
if (80<=grade)&(grade<=89):
    print('You grade is an B')
if (70<=grade)&(grade<=79):
    print('You grade is an C')
if (60<=grade)&(grade<=69):
    print('You grade is an D')
if (grade<=59):
    print('You grade is an F')
